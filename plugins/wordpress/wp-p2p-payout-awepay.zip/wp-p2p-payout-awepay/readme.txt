Place wp-p2p-payout-awepay folder into wp-content/plugins directory and activate in wordpress backend. Configure in Awepay P2P settings form.
