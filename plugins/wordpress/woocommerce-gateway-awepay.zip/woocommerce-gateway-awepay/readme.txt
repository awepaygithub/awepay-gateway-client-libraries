Place woocommerce-gateway-awepay folder into wp-content/plugins directory and activate in wordpress backend. Configure in woocommerce settings.
